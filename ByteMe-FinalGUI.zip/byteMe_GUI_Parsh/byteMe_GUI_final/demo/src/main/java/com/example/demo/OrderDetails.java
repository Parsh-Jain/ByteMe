package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class OrderDetails {
    int id;
    String specialRequest;
    List<String> orderedItems;
    double totalCost;
    String isVIP;
    String status;

    public OrderDetails(int id, String specialRequest, List<String> orderedItems, double totalCost, String isVIP, String status) {
        this.id = id;
        this.specialRequest = specialRequest;
        this.orderedItems = orderedItems;
        this.totalCost = totalCost;
        this.isVIP = isVIP;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIsVIP() {  // Updated method name
        return isVIP;
    }

    public void setIsVIP(String isVIP) {  // Updated method name
        this.isVIP = isVIP;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }

    public List<String> getOrderedItems() {
        return orderedItems;
    }

    public String getSpecialRequest() {
        return specialRequest;
    }

    public void setSpecialRequest(String specialRequest) {
        this.specialRequest = specialRequest;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return id + ", " + specialRequest + ", " + orderedItems + ", " + totalCost + ", " + isVIP + ", " + status;
    }



}

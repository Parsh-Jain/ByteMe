package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MenuPage {
    public static void display(Stage stage) {
        // TableView for menu items
        TableView<Item> table = new TableView<>();
        ObservableList<Item> menuItems = FXCollections.observableArrayList();

        // Define columns
        TableColumn<Item, String> nameCol = new TableColumn<>("Item Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        nameCol.setMinWidth(100);

        TableColumn<Item, Double> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setMinWidth(100);

        TableColumn<Item, String> categoryCol = new TableColumn<>("Category");
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        categoryCol.setMinWidth(100);

        TableColumn<Item, Integer> quantityCol = new TableColumn<>("Quantity");
        quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        quantityCol.setMinWidth(100);

        table.getColumns().addAll(nameCol, priceCol, categoryCol, quantityCol);

        // Load initial data
        loadMenuData(menuItems);

        // Set items to the table
        table.setItems(menuItems);

        // Refresh button
        Button refreshButton = new Button("Refresh");
        refreshButton.setOnAction(e -> loadMenuData(menuItems));

        // Back button
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> Main.displayDashboard(stage));

        // Layout
        VBox root = new VBox(10, table, refreshButton, backButton);

        Scene scene = new Scene(root, 600, 400);
        stage.setTitle("Canteen Menu");
        stage.setScene(scene);
        stage.show();
    }

    private static void loadMenuData(ObservableList<Item> menuItems) {
        menuItems.clear(); // Clear old data
        try (BufferedReader reader = new BufferedReader(new FileReader("menu.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length == 4) {
                    Item item = new Item(
                            parts[0],
                            Double.parseDouble(parts[1]),
                            parts[2],
                            Integer.parseInt(parts[3])
                    );
                    menuItems.add(item);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading menu: " + e.getMessage());
        }
    }
}
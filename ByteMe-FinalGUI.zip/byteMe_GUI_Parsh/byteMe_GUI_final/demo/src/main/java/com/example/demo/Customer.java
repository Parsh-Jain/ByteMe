package com.example.demo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Iterator;
import java.util.stream.Collectors;

public class Customer{
    private String name;
    private String password;
    private String rollNo;
    private String address;
    private boolean isVIP = false;

    ArrayList<Item> cart = new ArrayList<>();
    ArrayList<Order> orderHistory = new ArrayList<>();

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getRollNo() {
        return rollNo;
    }
    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public Customer(String name, String password, String rollNo, String address){
        this.name = name;
        this.password = password;
        this.rollNo = rollNo;
        this.address = address;
    }

    public void cartOperations(){
        System.out.println("What would you like to do in your cart? ");
        System.out.println("1. Add Item");
        System.out.println("2. Remove Items");
        System.out.println("3. View cart total");
        System.out.println("4. Checkout");
        System.out.println("5. Exit Cart Operations");

        Scanner sc = new Scanner(System.in);
        String choice = sc.nextLine();

        switch(choice){
            case "1":
                addItemtoCart();
                break;
            case "2":
                removeItemFromCart();
                break;
            case "3":
                viewCartTotal();
                break;
            case "4":
                checkout();
                return;
            case "5":
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }

    public void addItemtoCart(){
        Admin.viewItems();
        System.out.print("Which item would you like to add to cart? ");
        Scanner sc = new Scanner(System.in);
        String inp = sc.nextLine();
        boolean avaialble = false;
        for(Item item : Admin.allItems){
            if(inp.equals(item.getItemName()) && item.getQuantity() > 0){
                avaialble = true;
                cart.add(item);
                System.out.println(item.getItemName() + " has been added to cart");
                item.quantity--;
                break;
            }
        }
        if(!avaialble){
            System.out.println("That item is not available. Please try again.");
        }
    }

    public void viewCart(){
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            System.out.println("Items in cart:");
            for (Item item : cart) {
                System.out.print(item.getItemName() + " | ");
            }
            System.out.println();
        }
    }

    public void removeItemFromCart() {
        viewCart();
        if (cart.isEmpty()) return;
        System.out.print("Enter the item name to remove: ");
        Scanner sc = new Scanner(System.in);
        String inp = sc.nextLine();

        Iterator<Item> iterator = cart.iterator();
        while (iterator.hasNext()) {
            Item item = iterator.next();
            if (item.getItemName().equals(inp)) {
                iterator.remove();
                item.setQuantity(item.getQuantity() + 1);
                System.out.println(item.getItemName() + " has been removed from the cart.");
                return;
            }
        }
        System.out.println("Item not found in cart.");
    }

    public void viewCartTotal(){
        double sum = 0;
        for(Item item : cart){
            sum += item.getPrice();
        }
        System.out.println("Total cost: " + sum);
    }

    public void checkout(){
        if (cart.isEmpty()) {
            System.out.println("Cart is empty. Add items to proceed with checkout.");
            return;
        }
        Scanner sc = new Scanner(System.in);
        placeOrder();
        //System.out.println("Your order details are: ");
        System.out.print("Would you like to checkout? (yes/no) ");
        String inp = sc.nextLine();
        if(inp.equals("yes")){
            System.out.println("Address to Be delivered at: " + getAddress());
            System.out.print("Would you like to pay using UPI / card? ");
            String inp2 = sc.nextLine();
            System.out.println("Confirming order....");
            System.out.println("Order is confirmed, will be delivered soon");
            cart.clear();
        }
        saveCartToFile();
    }

//    public void writeOrderToFile(Order order) {
//        try (BufferedWriter writer = new BufferedWriter(new FileWriter("pending_orders.txt", true))) {
//            writer.write(formatOrderForFile(order));
//            writer.newLine();
//        } catch (IOException e) {
//            System.out.println("Error writing order to file: " + e.getMessage());
//        }
//    }
//
//    private String formatOrderForFile(Order order) {
//        // Customize this based on the Order class structure
//        return String.join(", ",
//                String.valueOf(order.getId()),
//                order.getSpecialRequest().isEmpty() ? "None" : order.getSpecialRequest(),
//                order.getOrderedItems().toString(),  // Adjust to stringify items
//                String.valueOf(order.getTotalCost()),
//                order.getisVIP() ? "VIP" : "Non-VIP",
//                order.getStatus()
//        );
//    }

    public void writeOrderToFile(Order order) {
        OrderDetails orderDetails = new OrderDetails(
                order.getId(),
                order.getSpecialRequest(),
                formatOrderedItems(order.getOrderedItems()),
                order.getTotalCost(),
                order.getisVIP() ? "VIP" : "Non-VIP",
                order.getStatus()
        );
        OrdersPage.saveOrder(orderDetails);
    }

    private List<String> formatOrderedItems(ArrayList<Item> items) {
        return items.stream()
                .map(Item::getItemName)
                .collect(Collectors.toList());
    }

    public void writeOrderHistoryToFile(Order order) {
        String filename = this.name + "_order_history.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(formatOrderForOrderHistory(order));
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error writing order to file: " + e.getMessage());
        }
    }

    private String formatOrderForOrderHistory(Order order) {
        return String.join(", ",
                String.valueOf(order.getId()),
                order.getSpecialRequest().isEmpty() ? "None" : order.getSpecialRequest(),
                formatOrderedItems(order.getOrderedItems()).toString(),
                String.valueOf(order.getTotalCost()),
                order.getisVIP() ? "VIP" : "Non-VIP",
                order.getStatus()
        );
    }

    public void saveCartToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(this.name + "_cart.txt"))) {
            for (Item item : cart) {
                writer.write(item.getItemName() + ", " + item.getQuantity());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving cart: " + e.getMessage());
        }
    }

    public void loadCartFromFile() {
        cart.clear();
        try (Scanner scanner = new Scanner(new File(this.name + "_cart.txt"))) {
            while (scanner.hasNextLine()) {
                String[] itemDetails = scanner.nextLine().split(", ");
                String itemName = itemDetails[0];
                int quantity = Integer.parseInt(itemDetails[1]);
                for (Item item : Admin.allItems) {
                    if (item.getItemName().equals(itemName)) {
                        item.setQuantity(quantity);
                        cart.add(item);
                        break;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading cart: " + e.getMessage());
        }
    }


    public void placeOrder(){
        Scanner sc = new Scanner(System.in);
        System.out.print("If there is any special request type here, else leave empty: ");
        String inp = sc.nextLine();
        System.out.println("Your order details are: ");
        Order order = new Order(this, cart, inp);
        if(this.isVIP){
            order.setisVIP(true);
        }
        order.orderDetails();
        Admin.pendingOrders.add(order);
        orderHistory.add(order);
        writeOrderToFile(order);
        writeOrderHistoryToFile(order);
    }

    public void pastOrders(){
        for(Order order : orderHistory){
            order.orderDetails();
            System.out.println("----------------------------");
        }
    }

    public void cancelOrder(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Orders currently in received state: ");
        for(Order order : orderHistory) {
            if (order.getStatus().equals("Received")) {
                order.orderDetails();
            }
        }
        System.out.print("Enter order ID which you would like to cancel: ");
        int id = Integer.parseInt(sc.nextLine());
        for(Order order : orderHistory) {
            if(order.getId() == id){
                Admin.pendingOrders.remove(order);
                orderHistory.remove(order);
                System.out.println("Order has been cancelled");
            }
        }
    }

    public void addReview(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Which item would you like to review? ");
        String inp = sc.nextLine();
        for(Item item : Admin.allItems){
            if(inp.equals(item.getItemName())){
                System.out.print("Enter your review: ");
                String review = sc.nextLine();
                item.itemReview.add(review);
                System.out.println("Review added successfully");
                break;
            }
        }
    }

    public void viewReview(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter item name whose review you would like to view: ");
        String inp = sc.nextLine();
        for(Item item : Admin.allItems){
            if(inp.equals(item.getItemName())){
                System.out.println(item.itemReview);
            }
        }
    }

    public void becomeVIP(){
        if(this.isVIP){
            System.out.println("Already a VIP member");
            return;
        }
        System.out.println("Using coupon and becoming a VIP member...");
        this.isVIP = true;
        System.out.println("VIP membership has been successfully activated");
    }

    public void replacePreviousOrder(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Previous order details are: ");
        pastOrders();
        System.out.print("Enter Order ID of order which you would like to replace: ");
        int inp = Integer.parseInt(sc.nextLine());
        for(Order order : orderHistory){
            if(inp == order.getId()){
                cart = order.getOrderedItems();
                placeOrder();
                break;
            }
        }
    }

    public void OrderTracking(){
        if(orderHistory.isEmpty()){
            System.out.println("No order history to show");
            return;
        }
        Scanner sc = new Scanner(System.in);
        System.out.println("1. View order(s) status:");
        System.out.println("2. Cancel order:");
        System.out.println("3. View Order history:");
        System.out.println("4. Replace previous order:");
        System.out.println("5. Exit");

        String inp = sc.nextLine();

        switch (inp){
            case "1":
                if(this.orderHistory.isEmpty()){
                    System.out.println("No order history to show");
                    break;
                }
                for(Order order : this.orderHistory){
                    System.out.println(order.getId() + " | " + order.getStatus());
                }
                break;
            case "2":
                cancelOrder();
                break;
            case "3":
                for(Order order : this.orderHistory){
                    order.orderDetails();
                    System.out.println("-----------------------");
                }
                break;
            case "4":
                replacePreviousOrder();
                break;
            case "5":
                return;

        }
    }



}


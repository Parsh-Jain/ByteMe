package com.example.demo;

import java.util.ArrayList;
import java.util.Scanner;

public class Item {
    private String itemName;
    private double price; // Change price to double
    private String category;
    public int quantity;

    ArrayList<String> itemReview = new ArrayList<>();

    public Item(String itemName, double price, String category, int quantity) {
        this.itemName = itemName;
        this.price = price;
        this.category = category;
        this.quantity = quantity;

    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCategory(){
        return category;
    }

    public void setCategory(String category){
        this.category = category;
    }
}


package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class OrdersPage {

    public static void display(Stage stage) {
        TableView<OrderDetails> table = new TableView<>();
        ObservableList<OrderDetails> pendingOrders = FXCollections.observableArrayList();

        // Define table columns
        TableColumn<OrderDetails, Integer> idCol = new TableColumn<>("Order ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setMinWidth(100);

        TableColumn<OrderDetails, String> requestCol = new TableColumn<>("Special Request");
        requestCol.setCellValueFactory(new PropertyValueFactory<>("specialRequest"));
        requestCol.setMinWidth(200);

        TableColumn<OrderDetails, String> itemsCol = new TableColumn<>("Ordered Items");
        itemsCol.setCellValueFactory(data -> {
            List<String> items = data.getValue().getOrderedItems();
            return new javafx.beans.property.SimpleStringProperty(String.join(", ", items));
        });
        itemsCol.setMinWidth(200);

        TableColumn<OrderDetails, Double> costCol = new TableColumn<>("Total Cost");
        costCol.setCellValueFactory(new PropertyValueFactory<>("totalCost"));
        costCol.setMinWidth(100);

        TableColumn<OrderDetails, String> vipCol = new TableColumn<>("VIP");
        vipCol.setCellValueFactory(new PropertyValueFactory<>("isVIP"));
        vipCol.setMinWidth(50);

        TableColumn<OrderDetails, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setMinWidth(100);

        table.getColumns().addAll(idCol, requestCol, itemsCol, costCol, vipCol, statusCol);

        // Load orders from file
        loadPendingOrders(pendingOrders);
        table.setItems(pendingOrders);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> Main.displayDashboard(stage));

        VBox root = new VBox(10, table, backButton);

        Scene scene = new Scene(root, 800, 600);
        stage.setTitle("Pending Orders");
        stage.setScene(scene);
        stage.show();
    }

    private static void loadPendingOrders(ObservableList<OrderDetails> pendingOrders) {
        pendingOrders.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("pending_orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length == 6) {
                    List<String> items = Arrays.asList(parts[2].split(";")); // Assuming items are separated by semicolons
                    OrderDetails order = new OrderDetails(
                            Integer.parseInt(parts[0]),   // ID
                            parts[1],                     // Special Request
                            items,                        // Ordered Items
                            Double.parseDouble(parts[3]), // Total Cost
                            parts[4],                     // VIP
                            parts[5]                      // Status
                    );
                    pendingOrders.add(order);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading pending orders: " + e.getMessage());
        }
    }

    public static void saveOrder(OrderDetails order) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("pending_orders.txt", true))) {
            writer.write(formatOrderForFile(order));
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving order: " + e.getMessage());
        }
    }

    private static String formatOrderForFile(OrderDetails order) {
        return String.join(", ",
                String.valueOf(order.getId()),
                order.getSpecialRequest(),
                String.join(";", order.getOrderedItems()), // Join items with semicolons
                String.valueOf(order.getTotalCost()),
                order.getIsVIP(),
                order.getStatus()
        );
    }
}

package com.example.demo;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class Main extends Application {
    public static Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        Main.primaryStage = primaryStage;
        displayDashboard(primaryStage);
    }

    public static void displayDashboard(Stage stage) {
        VBox root = new VBox(30);
        Button menuButton = new Button("View Menu");
        Button ordersButton = new Button("View Pending Orders");
        Button exitButton = new Button("Exit");

        menuButton.setOnAction(e -> MenuPage.display(stage));
        ordersButton.setOnAction(e -> OrdersPage.display(stage));
        exitButton.setOnAction(e -> stage.close());

        root.getChildren().addAll(menuButton, ordersButton, exitButton);

        Scene scene = new Scene(root, 400, 300);
        stage.setTitle("Canteen Dashboard");
        stage.setScene(scene);
        stage.show();
    }

    public static void openNewWindow() {
        Stage newStage = new Stage();
        displayDashboard(newStage);
        newStage.show();
    }

    static ArrayList<Customer> allCustomers = new ArrayList<>();

    public static void main(String[] args) {

        File myFile = new File("pending_orders.txt");
        try {
            myFile.createNewFile();
        } catch (IOException e) {
            System.out.println("Unable to create test file");
            e.printStackTrace();
        }

        File myFile2 = new File("menu.txt");
        try {
            myFile2.createNewFile();
        } catch (IOException e) {
            System.out.println("Unable to create test file");
            e.printStackTrace();
        }

        Customer c1 = new Customer("Parsh", "123", "2023368", "H2-921");
        allCustomers.add(c1);

        Item i1 = new Item("Pizza", 100, "Meal", 1);
        Item i2 = new Item("Burger", 80, "Meal", 2);
        Item i3 = new Item("Milk", 20, "Beverage", 2);
        Item i4 = new Item("Samosa", 10, "Snack", 2);

        Admin.allItems.add(i1);
        Admin.allItems.add(i2);
        Admin.allItems.add(i3);
        Admin.allItems.add(i4);
        Admin.addItemToMenu();


        System.out.println("Welcome to the IIIT-Delhi Food Page!");


        while (true) {
            Scanner sc = new Scanner(System.in);

            System.out.println("1. Signup as Customer");
            System.out.println("2. Login as Customer");
            System.out.println("3. Login as Admin");
            System.out.println("4. View GUI");
            System.out.println("5. Exit");

            String inp = sc.nextLine();

            switch (inp) {
                case "1":
                    signup();
                    break;
                case "2":
                    login();
                    break;
                case "3":
                    admin_login();
                    break;
                case "4":
                    launch(args);
                    break;
                case "5":
                    return;
                default:
                    System.out.println("Invalid input, please try again");
                    break;
            }
        }
    }

    public static void login() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter your rollNo: ");
        String rollNo = sc.nextLine();
        System.out.print("Please enter your password: ");
        String password = sc.nextLine();

        boolean found = false;

        for (Customer customer : allCustomers) {
            if (customer.getRollNo().equals(rollNo) && customer.getPassword().equals(password)) {
                System.out.println("Welcome " + customer.getName());
                found = true;
                customerInterface(customer);
                break;
            }
        }
        if (!found) {
            System.out.println("Customer not found, please try again");
        }
    }

    public static void signup() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter your name: ");
        String name = sc.nextLine();
        System.out.print("Please enter your rollNo: ");
        String rollNo = sc.nextLine();
        System.out.print("Please enter your password: ");
        String password = sc.nextLine();
        System.out.print("Please enter your address: ");
        String address = sc.nextLine();

        allCustomers.add(new Customer(name, rollNo, password, address));
        //customerInterface();
        System.out.println("Registration successful");

    }

    public static void admin_login() {
        //String adminPassword = "12345";
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter your password: ");
        String admin_password = sc.nextLine();
        if (admin_password.equals(Admin.adminPassword)) {
            System.out.println("Welcome Administrator to the IIIT-Delhi Food Page!");
            adminInterface();
        } else {
            System.out.println("Invalid password, please try again");
        }
    }

    public static void customerInterface(Customer customer) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please choose one of the following options: ");
        while (true) {
            System.out.println("1. Browse Menu");
            System.out.println("2. Cart Operations");
            System.out.println("3. Order Tracking");
            System.out.println("4. Item reviews");
            System.out.println("5. Become VIP member");
            System.out.println("6. Exit");

            String inp = sc.nextLine();

            switch (inp) {
                case "1":
                    System.out.println("1. View all items");
                    System.out.println("2. Search item by name");
                    System.out.println("3. Filter by category");
                    System.out.println("4. Sort by price");
                    System.out.println("5. Exit");

                    String inp2 = sc.nextLine();

                    switch (inp2) {
                        case "1":
                            Admin.viewItems();
                            //launch(args);
                            break;
                        case "2":
                            System.out.print("Enter name of item which you would like to search: ");
                            String search_item = sc.nextLine();
                            boolean found = false;

                            for (Item item : Admin.allItems) {
                                if (item.getItemName().equals(search_item)) {
                                    if (item.getQuantity() > 0) {
                                        System.out.println("This item is available");
                                        System.out.println(item.getItemName() + " | " + item.getCategory() + "  | " + item.getPrice() + "rs");
                                        found = true;
                                    }
                                    break;
                                }
                            }
                            if (!found) {
                                System.out.println("Item is not available");
                            }
                            break;

                        case "3":
                            System.out.println("Which category would you like to view:\n1. Snacks\n2. Beverages\n3. Meals");
                            String inp1 = sc.nextLine();

                            switch(inp1){
                                case "1":
                                    for(Item item: Admin.allItems){
                                        if(item.getCategory().equals("Snack")){
                                            System.out.println(item.getItemName() + " | " + item.getPrice() + "rs");
                                        }
                                    }
                                    break;
                                case "2":
                                    for(Item item: Admin.allItems){
                                        if(item.getCategory().equals("Beverage")){
                                            System.out.println(item.getItemName() + " | " + item.getPrice()+ "rs");
                                        }
                                    }
                                    break;
                                case "3":
                                    for(Item item: Admin.allItems){
                                        if(item.getCategory().equals("Meal")){
                                            System.out.println(item.getItemName() + " | " + item.getPrice());
                                        }
                                    }
                                    break;
                            }
                            break;

                        case "4":
                            // Sorting items based on price in ascending order
                            Collections.sort(Admin.allItems, new Comparator<Item>() {
                                @Override
                                public int compare(Item i1, Item i2) {
                                    return Double.compare(i1.getPrice(), i2.getPrice());
                                }
                            });

                            System.out.println("Items sorted by price:");
                            for (Item item : Admin.allItems) {
                                System.out.println(item.getItemName() + " | " + item.getCategory() + " | " + item.getPrice() + "rs");
                            }
                            break;
                        case "5":
                            break;

                        default:
                            System.out.println("Invalid input, please try again");
                            break;
                    }
                    break;
                case "2":
                    customer.cartOperations();
                    break;
                case "3":
                    customer.OrderTracking();
                    break;
                case "4":
                    System.out.println("What would you like to do:\n1. Add review\n2. View review");
                    String ans = sc.nextLine();
                    if(ans.equals("1")){
                        customer.addReview();
                    }else{
                        customer.viewReview();
                    }
                    break;
                case "5":
                    customer.becomeVIP();;
                    break;
                case "6":
                    return;
            }

        }
    }

    public static void adminInterface() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please choose one of the following options: ");

        while (true) {
            System.out.println("1. Menu Management");
            System.out.println("2. Order Management");
            System.out.println("3. Report Generation");
            System.out.println("4. Exit");

            String inp = sc.nextLine();

            switch (inp) {
                case "1":
                    System.out.println("1. Add new Item");
                    System.out.println("2. Update existing Item Details");
                    System.out.println("3. Remove Item");
                    System.out.println("4. Exit");

                    String inp2 = sc.nextLine();

                    switch (inp2) {
                        case "1":
                            Admin.addItem();
                            break;
                        case "2":
                            Admin.updateItem();
                            break;
                        case "3":
                            Admin.removeItem();
                            break;
                        case "4":
                            break;
                    }
                    break;

                case "2":
                    System.out.println("1. View Pending orders");
                    System.out.println("2. Update order status");
                    System.out.println("3. Process Refunds");
                    System.out.println("4. Exit");

                    String inp3 = sc.nextLine();

                    switch (inp3) {
                        case "1":
                            Admin.viewPendinOrders();
                            break;
                        case "2":
                            System.out.print("Enter order ID whose status you want to update: ");
                            int ans = Integer.parseInt(sc.nextLine());
                            for(Order order : Admin.pendingOrders){
                                if(order.getId() == ans){
                                    System.out.print("Enter new status (Received, Processing, Out for Delivery, Denied): ");
                                    String inp4 = sc.nextLine();
                                    order.updateStatus(inp4);
                                    if(inp4.equals("Out for Delivery")){
                                        Admin.completedOrders.add(order);
                                        Admin.pendingOrders.remove(order);
                                    }if(inp4.equals("Denied")){
                                        Admin.completedOrders.remove(order);
                                        Admin.deniedOrders.add(order);
                                    }
                                    System.out.println("Order status has been updated");
                                    break;
                                }
                            }
                            break;
                        case "3":
                            Admin.processRefunds();
                            break;
                        case "4":
                            break;
                    }
                    break;
                case "3":
                    Admin.generateDailySalesReport();
                    break;
                case "4":
                    return;
            }
        }
    }
}
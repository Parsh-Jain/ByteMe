package com.example.demo;

import java.util.ArrayList;
import java.sql.Timestamp;
import java.util.Date;

public class Order {
    private static int orderIdNumbers = 1;

    private int id;
    private Customer customer;
    private ArrayList<Item> OrderedItems;
    private double totalCost;
    private String status; // can be recieved, preparing, out for delivery
    private String specialRequest;
    private boolean isVIP = false;
    private Timestamp orderTimestamp;

    public static int getOrderIdNumbers() {
        return orderIdNumbers;
    }

    public static void setOrderIdNumbers(int orderIdNumbers) {
        Order.orderIdNumbers = orderIdNumbers;
    }

    public boolean getisVIP(){
        return isVIP;
    }

    public void setisVIP(boolean isVIP){
        this.isVIP = isVIP;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public ArrayList<Item> getOrderedItems() {
        return OrderedItems;
    }

    public void setOrderedItems(ArrayList<Item> orderedItems) {
        OrderedItems = orderedItems;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSpecialRequest() {
        return specialRequest;
    }

    public void setSpecialRequest(String specialRequest) {
        this.specialRequest = specialRequest;
    }

    public Timestamp getOrderTimestamp() {
        return orderTimestamp;
    }

    public Order(Customer customer, ArrayList<Item> OrderedItems, String specialRequest) {
        this.id = orderIdNumbers++;
        this.customer = customer;
        this.OrderedItems = new ArrayList<>(OrderedItems);
        this.specialRequest = specialRequest;
        this.status = "Received";
        this.totalCost = OrderTotal();
        this.orderTimestamp = new Timestamp(System.currentTimeMillis());
    }

    public double OrderTotal(){
        double sum = 0;
        for(Item item : OrderedItems){
            sum += item.getPrice();
        }
        return sum;
    }

    public void updateStatus(String status){
        this.status = status;
    }

    public void orderDetails(){
        System.out.println("Order ID: " + id);
        if(!specialRequest.isEmpty()){
            System.out.println("Special Request: " + specialRequest);
        }

        for (Item item : OrderedItems) {
            System.out.println("- " + item.getItemName() + " | " + item.getPrice() + "rs");
        }
        System.out.println("Total Cost: " + totalCost + "rs");
        System.out.println("Order Status: " + status);
    }
}


package com.example.demo;

import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;
import java.sql.Timestamp;
import java.util.Calendar;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class Admin {
    public static String adminPassword = "12345";
    static ArrayList<Item> allItems = new ArrayList<>();
    static ArrayList<Order> pendingOrders = new ArrayList<>();
    static ArrayList<Order> completedOrders = new ArrayList<>();
    static ArrayList<Order> deniedOrders = new ArrayList<>();

    public static void addItemToMenu(){
        for(Item item: allItems){
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("menu.txt", true))) {
                writer.write(item.getItemName() + ", " + item.getPrice() + ", " + item.getCategory() + ", " + item.getQuantity()+ "\n");
            } catch (IOException e) {
                System.out.println("Error writing to file: " + e.getMessage());
            }
        }
    }

//    public static void addPendingOrderstoFile(){
//        for (Order order : pendingOrders){
//            try (BufferedWriter writer = new BufferedWriter(new FileWriter("pending_orders.txt", true))) {
//                writer.write(order.getId() + ", " + order.getCustomerEmail() + ", " + order.getSpecialRequest() + ", " + order.getOrderedItems() + ", " + order.getTotalCost() + ", " + order.getisVIP() + ", " + order.getStatus() + "\n");
//            } catch (IOException e) {
//                System.out.println("Error writing to file: " + e.getMessage());
//            }
//        }
//    }

//    public static void savePendingOrdersToFile() {
//        try (BufferedWriter writer = new BufferedWriter(new FileWriter("pending_orders.txt"))) {
//            for (Order order : pendingOrders) {
//                writer.write(order.getId() + ", " + order.getSpecialRequest() + ", " + order.getOrderedItems() + ", " + order.getTotalCost() + ", " + order.getisVIP() + ", " + order.getStatus() + "\n");
//            }
//        } catch (IOException e) {
//            System.out.println("Error writing to file: " + e.getMessage());
//        }
//    }

    public static void savePendingOrdersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("pending_orders.txt"))) {
            for (Order order : pendingOrders) {
                String orderedItems = formatOrderedItems(order.getOrderedItems());
                writer.write(String.format("%d, %s, %s, %s, %s, %s%n",
                        order.getId(),
                        order.getSpecialRequest().isEmpty() ? "None" : order.getSpecialRequest(),
                        orderedItems,
                        order.getTotalCost(),
                        order.getisVIP() ? "VIP" : "Non-VIP",
                        order.getStatus()
                ));
            }
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    private static String formatOrderedItems(ArrayList<Item> items) {
        StringBuilder sb = new StringBuilder();
        for (Item item : items) {
            if (sb.length() > 0) {
                sb.append(";");
            }
            sb.append(item.getItemName()).append(":").append(item.getQuantity());
        }
        return sb.toString();
    }


    public static void addItem() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of item: ");
        String name = sc.nextLine();
        System.out.print("Enter price: ");
        double price = Double.parseDouble(sc.nextLine());
        System.out.print("Enter its category: ");
        String category = sc.nextLine();
        System.out.print("Enter quantity available: ");
        int quantity = Integer.parseInt(sc.nextLine());

        Item newItem = new Item(name, price, category, quantity);
        allItems.add(newItem);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("menu.txt", true))) {
            writer.write(name + ", " + price + ", " + category + ", " + quantity + "\n");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        System.out.println("Item added successfully");
    }

    public static void updateItem() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of item which you would like to update: ");
        String name = sc.nextLine();
        boolean found = false;

        for (Item item : allItems) {
            if (item.getItemName().equals(name)) {
                found = true;
                System.out.println("What would you like to update: ");
                System.out.println("1. Update name");
                System.out.println("2. Update price");
                System.out.println("3. Update category");
                System.out.println("4. Update quantity");

                String inp = sc.nextLine();

                switch (inp) {
                    case "1":
                        System.out.print("Enter updated name: ");
                        String updated_name = sc.nextLine();
                        item.setItemName(updated_name);
                        break;
                    case "2":
                        System.out.print("Enter updated price: ");
                        double updated_price = Double.parseDouble(sc.nextLine());
                        item.setPrice(updated_price);
                        break;
                    case "3":
                        System.out.print("Enter updated category: ");
                        String updated_category = sc.nextLine();
                        item.setCategory(updated_category);
                        break;
                    case "4":
                        System.out.print("Enter updated quantity: ");
                        int updated_quantity = Integer.parseInt(sc.nextLine());
                        item.setQuantity(updated_quantity);
                        break;
                    default:
                        System.out.println("Invalid input");
                        break;
                }
                System.out.println("Item updated successsfully");
            }
        }
        if (!found) {
            System.out.println("Item not found");
        }
    }

    public static void viewItems() {

        for (Item item : allItems) {
            System.out.println(item.getItemName() + " | " + item.getCategory() + "  | " + item.getPrice() + "rs" + " Available quantity: " + item.getQuantity());
        }

        //MenuPage.display(Main.primaryStage);
    }

    public static void removeItem() {
        Scanner sc = new Scanner(System.in);
        viewItems();
        System.out.print("Enter name of item which you would like to remove: ");
        String item_remove = sc.nextLine();
        boolean found = false;

        Iterator<Item> iterator = allItems.iterator();
        while (iterator.hasNext()) {
            Item item1 = iterator.next();
            if (item1.getItemName().equals(item_remove)) {
                iterator.remove(); // Safely remove the item
                found = true;
                System.out.println("Item removed successfully");

                Iterator<Order> orderIterator = pendingOrders.iterator();
                while (orderIterator.hasNext()) {
                    Order order = orderIterator.next();
                    for (Item ordered_item : order.getOrderedItems()) {
                        if (ordered_item.getItemName().equals(item1.getItemName())) {
                            order.setStatus("Denied");
                            System.out.println("Removed " + ordered_item.getItemName() + " from order with ID " + order.getId());
                            orderIterator.remove(); // Safely remove order from pendingOrders
                            deniedOrders.add(order);
                            break;
                        }
                    }
                }
                break;
            }
        }
        if (!found) {
            System.out.println("Item not found");
        }
    }

    public static void pendingOrderDetails(Order order) {
        System.out.println("Order ID: " + order.getId());
        if (!order.getSpecialRequest().isEmpty()) {
            System.out.println("Special Request: " + order.getSpecialRequest());
        }

        for (Item item : order.getOrderedItems()) {
            System.out.println("- " + item.getItemName() + " | " + item.getPrice() + "rs");
        }
        System.out.println("Total Cost: " + order.OrderTotal() + "rs");
    }

    public static void viewPendinOrders() {
        if (pendingOrders.isEmpty()) {
            System.out.println("No orders pending");
            return;
        }
        for (Order order : pendingOrders) {
            if (order.getisVIP()) {
                pendingOrderDetails(order);
                System.out.println("----------------------------------");
            }
        }
        for (Order order : pendingOrders) {
            if (!order.getisVIP()) {
                pendingOrderDetails(order);
                System.out.println("----------------------------------");
            }
        }
    }


    public static void processRefunds() {
        for (Order order : deniedOrders) {
            System.out.println("Refund successfully for order id: " + order.getId() + " of amount " + order.OrderTotal() + "rs");
            deniedOrders.remove(order);
        }
        System.out.println("All refunds have been issued successfully");
    }

    public static void generateDailySalesReport() {
        if (completedOrders.isEmpty()) {
            System.out.println("No completed orders to report.");
            return;
        }

        for (Order order : completedOrders) {
            if (order.getOrderTimestamp() == null) {
                continue;
            }
        }

        Timestamp start = completedOrders.get(0).getOrderTimestamp();
        double dailyRevenue = 0;
        int orderCount = 0;
        int dayNumber = 1;

        for (Order order : completedOrders) {
            Timestamp orderTimestamp = order.getOrderTimestamp();

            // if order is withing current day
            if (orderTimestamp.getTime() - start.getTime() < 100 * 1000) {
                dailyRevenue += order.getTotalCost();
                orderCount++;
            } else {
                // Print report for the previous day
                System.out.println("Day " + dayNumber + " Summary:");
                System.out.println("Total orders completed: " + orderCount);
                System.out.println("Total sales: " + dailyRevenue + " rs");
                System.out.println("-------------------------------");

                // Reset counters for the new day
                dayNumber++;
                start = orderTimestamp;
                dailyRevenue = order.getTotalCost();
                orderCount = 1;
            }
        }

        System.out.println("Day " + dayNumber + " Summary:");
        System.out.println("Total orders completed: " + orderCount);
        System.out.println("Total sales: " + dailyRevenue + " rs");
        System.out.println("-------------------------------");
    }
}

